export interface IMovie {
  id: string;
  title: string;
  realease_data: string;
  poster_path: string;
}