import { IMovie } from "./movie.model";

export interface IMovieData {
  results: IMovie[]
}