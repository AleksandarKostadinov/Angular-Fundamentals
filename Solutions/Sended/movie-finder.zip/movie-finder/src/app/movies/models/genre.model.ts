export interface IGenre {
  name: string;
}